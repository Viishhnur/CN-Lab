#include <stdio.h>
#include <stdlib.h>
#define INF -1
#define MAXN 10

void initialize(int n, int cost[MAXN][MAXN], int dist[MAXN][MAXN], int next[MAXN][MAXN]) {
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++) {
      dist[i][j] = cost[i][j];
      if (cost[i][j] != INF && i != j) next[i][j] = j;
      else next[i][j] = -1;
    }
}
void print_routing_table(int n, int dist[MAXN][MAXN], int next[MAXN][MAXN]) {
  for (int i = 0; i < n; i++) {
    printf("Routing table for node %d:\n", i);
    printf("Destination\tNext Hop\tDistance\n");
    for (int j = 0; j < n; j++)
      if (dist[i][j] == INF) printf("%d\t\t-\t\tINF\n", j);
      else printf("%d\t\t%d\t\t%d\n", j, next[i][j], dist[i][j]);
    printf("\n");
  }
}

void routing(int n, int cost[MAXN][MAXN], int dist[MAXN][MAXN], int next[MAXN][MAXN]) {
  int updated;
  do {
    updated = 0;
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        for (int k = 0; k < n; k++) {
          if (dist[i][k] + dist[k][j] < dist[i][j]) {
            dist[i][j] = dist[i][k] + dist[k][j];
            next[i][j] = next[i][k];
            updated = 1;
          }
        }
      }
    }
  } while (updated);
}

int main() {
  int n, cost[MAXN][MAXN];
  int distVector[MAXN][MAXN];
  int nextHop[MAXN][MAXN];
  printf("Enter the number of nodes: ");
  scanf("%d", &n);
  printf("Enter the cost matrix (use %d for INF):\n", INF);
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++) scanf("%d", &cost[i][j]);

  initialize(n, cost, distVector, nextHop);
  routing(n, cost, distVector, nextHop);
  print_routing_table(n, distVector, nextHop);
  return 0;
}