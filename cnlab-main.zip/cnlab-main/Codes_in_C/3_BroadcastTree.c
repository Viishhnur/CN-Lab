#include <math.h>
#include <stdio.h>

typedef union _ip_ { __uint32_t bin; __uint8_t sgmt[4]; } ip;

#define plen_to_mask(p) ((0xffffffffU << (32 - p)))

void print_ip(ip address);

int main() {
  ip address;
  printf("Enter an IP address: ");
  scanf("%hhu.%hhu.%hhu.%hhu", &address.sgmt[3], &address.sgmt[2], &address.sgmt[1], &address.sgmt[0]);

  int plen;
  printf("Enter the prefix length: ");
  scanf("%d", &plen);

  if (plen <= 0 || plen >= 32) {
    printf("Invalid prefix length\n");
    return 1;
  }

  ip mask = {plen_to_mask(plen)};

  int nnets, mext;
  printf("Number of subnets required: ");
  scanf("%d", &nnets);
  for (mext = 0; mext < 32 - plen && pow(2, mext) < nnets; mext++);
  nnets = pow(2, mext);
  printf("\nNumber of subnets to be created: %d\n", nnets);
  printf("New Prefix Length: %d\n", plen + mext);

  ip new_mask = {plen_to_mask(plen - mext)};

  __uint32_t hps = (1 << (32 - plen - mext)) - 2;
  printf("Number of hosts per subnet: %d\n\n", hps);

  for (int i = 0; i < nnets; i++) {
    ip network, broadcast, first, last;
    network.bin = (address.bin & new_mask.bin) | i << (32 - plen - mext);
    broadcast.bin = network.bin | ~new_mask.bin;
    first.bin = network.bin + 1;
    last.bin = broadcast.bin - 1;

    printf("Subnet %d:\n", i + 1);
    printf("  Network address: ");  print_ip(network);
    printf("  First host: "); print_ip(first);
    printf("  Last host: "); print_ip(last);
    printf("  Broadcast address: "); print_ip(broadcast);
  }
}

void print_ip(ip address) {
  printf("%d.%d.%d.%d\n", address.sgmt[3], address.sgmt[2], address.sgmt[1], address.sgmt[0]);
}
