#include <stdio.h>
#include <string.h>

#define N strlen(gen)

char data[32], check[32], gen[16];

int data_length, i, j;

void XOR() {
  for (j = 1; j < N; j++) check[j] = ((check[j] == gen[j]) ? '0' : '1');
}

void crc() {
  for (i = 0; i < N; i++) check[i] = data[i];
  do {
    if (check[0] == '1') XOR();
    for (j = 0; j < N - 1; j++) check[j] = check[j + 1];
    check[j] = data[i++];
  } while (i <= data_length + N - 1);
}

int main() {
  printf("\nEnter data to be transmitted: ");
  scanf("%s", data);
  printf("\nEnter the Generating polynomial: ");
  scanf("%s", gen);
  
  data_length = strlen(data);
  for (i = data_length; i < data_length + N - 1; i++) data[i] = '0';
  printf("\nData padded with n-1 zeros : %s", data);

  crc();

  printf("\nCRC or Check value is : %s", check);
  for (i = data_length; i < data_length + N - 1; i++) data[i] = check[i - data_length];

  printf("\nFinal data to be sent : %s", data);

  printf("Enter the received data: ");
  scanf("%s", data);
  printf("Data received: %s", data);

  crc();

  for (i = 0; (i < N - 1) && (check[i] != '1'); i++);
  if (i < N - 1) printf("\nError detected\n\n");
  else printf("\nNo error detected\n\n");

  return 0;
}